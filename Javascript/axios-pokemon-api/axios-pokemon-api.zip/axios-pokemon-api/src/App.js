
import './App.css';
import Pokemon from './component/data';
import React from 'react';
function App() {

 
  return (
    <div className="App">
      <Pokemon/>
    </div>
  );
}

export default App;
