import logo from './logo.svg';
import './App.css';
import FormData from './components/form';
function App() {
  return (
    <div className="App">
      <FormData></FormData>
    </div>
  );
}

export default App;
