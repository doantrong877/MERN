import logo from './logo.svg';
import './App.css';
import Pokemon from './components/pokemon';
function App() {

 
  return (
    <div className="App">
      <Pokemon/>
    </div>
  );
}

export default App;
