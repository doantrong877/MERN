import React, {useState, useEffect} from "react";

const Pokemon = (props) => {
    const [pokemons, setPokemons] = useState([]);
    var isFetch = false;
    useEffect(() => {
        fetch('https://pokeapi.co/api/v2/pokemon?limit=807&offset=0')
        .then(response => response.json())
        .then(response => setPokemons(response.results))
    }, [isFetch]);
    const handleClick = () => {
       if(isFetch === true){
        isFetch = false;
       } else {
        isFetch = true;
       }
    }
   
   
    return (
       
        <div>
            <button onClick={handleClick}>Fetch Pokemon</button>
            {pokemons.length > 0 && pokemons.map((pokemon, index)=>{
                return(<div key={index}>{pokemon.name}</div>)
            })}
        </div>

      
    )
}
export default Pokemon;