import logo from './logo.svg';
import './App.css';
import TodoList from './Components/todo'
function App() {
  return (
    <div className="App">
    <TodoList/>
    </div>
  );
}

export default App;
