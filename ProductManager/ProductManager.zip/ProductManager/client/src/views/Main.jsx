import ProductForm from "../components/ProductForm";
import React, {useEffect, useState} from "react";
export default () => {
    return (
        <div>
            <ProductForm/>
        </div>
    )
}
